import React from "react";

function ErrorComponent() {
    return <div>This is an error page</div>

}

export default ErrorComponent